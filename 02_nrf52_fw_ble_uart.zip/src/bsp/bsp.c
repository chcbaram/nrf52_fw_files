/*
 * bsp.c
 *
 *  Created on: 2017. 3. 10.
 *      Author: Baram
 */


#include "bsp.h"



void bspInit(void)
{

  nrf_drv_systick_init();

}

void bspDeinit()
{
}




